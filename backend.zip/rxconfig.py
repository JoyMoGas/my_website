import reflex as rx

config = rx.Config(
    app_name="joy_web",
    api_url="http://joymogasweb:8000",
)
